export enum PrayerStatus {
  ONGOING = 'ONGOING',
  ANSWERED = 'ANSWERED',
  SHARED = 'SHARED'
}

export enum CategoryType {
  FAMILY = 'FAMILY',
  GUIDANCE = 'GUIDANCE',
  HEALTH = 'HEALTH',
  WORK = 'WORK',
  OTHER = 'OTHER'
}

export interface Prayer {
  id: string;
  title: string;
  content: string;
  category: CategoryType;
  status: PrayerStatus;
  createdAt: Date;
  prayedCount: number;
}

export interface User {
  id: string;
  name: string;
  avatarUrl: string;
}
