import React from 'react';
import { PrayerWall } from './components/PrayerWall';
import { BottomNav } from './components/BottomNav';

function App() {
  return (
    <div className="w-full min-h-screen bg-white">
      <div className="max-w-md mx-auto min-h-screen bg-gradient-to-b from-teal-50 to-emerald-50 shadow-2xl relative overflow-hidden">
        <PrayerWall />
        <BottomNav />
      </div>
    </div>
  );
}

export default App;
