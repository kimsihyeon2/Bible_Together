import React, { useState, useEffect } from 'react';
import { ChevronLeft, Plus } from 'lucide-react';
import { Prayer, PrayerStatus, CategoryType } from '../types';
import { MOCK_PRAYERS, DAILY_VERSE } from '../constants';
import { PrayerCard } from './PrayerCard';
import { AddPrayerModal } from './AddPrayerModal';

export const PrayerWall: React.FC = () => {
  const [prayers, setPrayers] = useState<Prayer[]>(MOCK_PRAYERS);
  const [activeTab, setActiveTab] = useState<PrayerStatus>(PrayerStatus.ONGOING);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const ongoingCount = prayers.filter(p => p.status === PrayerStatus.ONGOING).length;
  const answeredCount = prayers.filter(p => p.status === PrayerStatus.ANSWERED).length;

  const handleAddPrayer = (title: string, content: string, category: CategoryType) => {
    const newPrayer: Prayer = {
      id: Date.now().toString(),
      title,
      content,
      category,
      status: PrayerStatus.ONGOING,
      createdAt: new Date(),
      prayedCount: 0,
    };
    setPrayers([newPrayer, ...prayers]);
  };

  const handlePray = (id: string) => {
    setPrayers(prayers.map(p => 
      p.id === id ? { ...p, prayedCount: p.prayedCount + 1 } : p
    ));
  };

  const filteredPrayers = prayers.filter(p => p.status === activeTab);

  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-50 to-emerald-50 pb-24">
      {/* Top Header */}
      <header className="pt-8 pb-4 px-6 flex items-center justify-between sticky top-0 bg-gradient-to-b from-teal-50/95 to-teal-50/80 backdrop-blur-sm z-30">
        <button className="p-2 -ml-2 rounded-full hover:bg-black/5 text-slate-700">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-bold text-slate-800 tracking-tight">Prayer Wall</h1>
        <div className="w-10 h-10 rounded-full bg-orange-200 border-2 border-white shadow-sm overflow-hidden">
          <img src="https://picsum.photos/100/100" alt="Profile" className="w-full h-full object-cover opacity-90 hover:opacity-100 transition-opacity" />
        </div>
      </header>

      <main className="px-5">
        {/* Journal Section */}
        <section className="relative mb-8 mt-2">
           {/* Book Page Effect */}
          <div className="bg-[#fefcf8] rounded-xl shadow-[0_10px_20px_-5px_rgba(0,0,0,0.1),inset_16px_0_20px_-10px_rgba(0,0,0,0.05)] border-l-4 border-l-[#e3d8c8] p-6 relative overflow-hidden">
             {/* Decorative lines like notebook paper */}
             <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-50" 
                  style={{
                    backgroundImage: 'linear-gradient(#e5e7eb 1px, transparent 1px)',
                    backgroundSize: '100% 32px',
                    marginTop: '40px'
                  }}>
             </div>

            <h2 className="text-2xl font-bold text-slate-800 mb-2 font-serif relative z-10">My Prayers</h2>
            <p className="text-slate-600 italic font-serif text-sm leading-relaxed mb-6 relative z-10 bg-[#fefcf8]/60 backdrop-blur-[1px] rounded p-1">
              "{DAILY_VERSE}"
            </p>

            <button 
              onClick={() => setIsModalOpen(true)}
              className="w-full bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700 text-white font-semibold py-3 px-4 rounded-full shadow-lg shadow-emerald-200 flex items-center justify-center gap-2 transition-all relative z-10"
            >
              <div className="bg-white/20 p-1 rounded-full">
                <Plus className="w-4 h-4 text-white" />
              </div>
              Add New Prayer
            </button>
            
            {/* Subtle decorative circle in top right like the screenshot */}
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-orange-100/50 rounded-full blur-2xl pointer-events-none"></div>
          </div>
        </section>

        {/* Tabs */}
        <div className="flex items-end gap-1 mb-4 overflow-x-auto scrollbar-hide px-1">
          <button
            onClick={() => setActiveTab(PrayerStatus.ONGOING)}
            className={`px-5 py-2.5 rounded-t-lg text-sm font-semibold transition-all relative ${
              activeTab === PrayerStatus.ONGOING
                ? 'bg-gradient-to-b from-white to-green-50/30 text-emerald-700 shadow-[0_-2px_4px_rgba(0,0,0,0.02)] z-10'
                : 'bg-white/40 text-slate-500 hover:bg-white/60'
            }`}
          >
            Ongoing <span className="ml-1 opacity-70">({ongoingCount})</span>
            {activeTab === PrayerStatus.ONGOING && (
              <div className="absolute bottom-0 left-0 w-full h-1 bg-emerald-500 rounded-t-full"></div>
            )}
          </button>
          
          <button
            onClick={() => setActiveTab(PrayerStatus.ANSWERED)}
            className={`px-5 py-2.5 rounded-t-lg text-sm font-semibold transition-all relative ${
              activeTab === PrayerStatus.ANSWERED
                ? 'bg-gradient-to-b from-white to-green-50/30 text-emerald-700 shadow-[0_-2px_4px_rgba(0,0,0,0.02)] z-10'
                : 'bg-white/40 text-slate-500 hover:bg-white/60'
            }`}
          >
            Answered <span className="ml-1 opacity-70">({answeredCount})</span>
            {activeTab === PrayerStatus.ANSWERED && (
              <div className="absolute bottom-0 left-0 w-full h-1 bg-emerald-500 rounded-t-full"></div>
            )}
          </button>

           <button className="px-5 py-2.5 rounded-t-lg text-sm font-semibold bg-white/40 text-slate-500 hover:bg-white/60 transition-all opacity-60">
            Shared
          </button>
        </div>

        {/* Prayer List */}
        <div className="space-y-6 min-h-[300px]">
          {filteredPrayers.length > 0 ? (
            filteredPrayers.map(prayer => (
              <PrayerCard key={prayer.id} prayer={prayer} onPray={handlePray} />
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-slate-400">
              <p className="text-sm">No {activeTab.toLowerCase()} prayers yet.</p>
            </div>
          )}
        </div>
      </main>

      <AddPrayerModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onAdd={handleAddPrayer} 
      />
    </div>
  );
};
