import React from 'react';
import { Heart, Briefcase, Activity, HelpCircle, MoreHorizontal, CheckCircle2, Clock } from 'lucide-react';
import { CategoryType, Prayer } from '../types';

interface PrayerCardProps {
  prayer: Prayer;
  onPray: (id: string) => void;
}

const getCategoryIcon = (category: CategoryType) => {
  switch (category) {
    case CategoryType.FAMILY:
      return <Heart className="w-5 h-5 text-orange-500 fill-orange-500" />;
    case CategoryType.GUIDANCE:
      return <Briefcase className="w-5 h-5 text-blue-500 fill-blue-500" />;
    case CategoryType.HEALTH:
      return <Activity className="w-5 h-5 text-red-500 fill-red-500" />;
    default:
      return <HelpCircle className="w-5 h-5 text-gray-500" />;
  }
};

const getCategoryColor = (category: CategoryType) => {
  switch (category) {
    case CategoryType.FAMILY: return 'bg-orange-100';
    case CategoryType.GUIDANCE: return 'bg-blue-100';
    case CategoryType.HEALTH: return 'bg-red-100';
    default: return 'bg-gray-100';
  }
};

const formatDate = (date: Date) => {
  const diffTime = Math.abs(Date.now() - date.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  if (diffDays === 1) return 'Added yesterday';
  return `Added ${diffDays} days ago`;
};

export const PrayerCard: React.FC<PrayerCardProps> = ({ prayer, onPray }) => {
  return (
    <div className="relative mb-6">
      {/* Stack effect behind the card */}
      <div className="absolute inset-x-1 bottom-[-4px] h-full bg-white rounded-xl border border-stone-200 shadow-sm z-0"></div>
      <div className="absolute inset-x-2 bottom-[-8px] h-full bg-white rounded-xl border border-stone-200 shadow-sm z-[-1]"></div>

      <div className="relative bg-[#fdfbf7] p-5 rounded-xl border border-stone-100 shadow-sm z-10 flex flex-col gap-3">
        {/* Header: Category & Menu */}
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-full ${getCategoryColor(prayer.category)}`}>
              {getCategoryIcon(prayer.category)}
            </div>
            <span className="text-xs font-bold tracking-wider text-slate-500 uppercase">
              {prayer.category}
            </span>
          </div>
          <button className="text-slate-400 hover:text-slate-600">
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="py-1">
          <h3 className="text-lg font-bold text-slate-800 mb-1 leading-snug">
            {prayer.title}
          </h3>
          <p className="text-slate-600 text-sm leading-relaxed border-b border-stone-200 pb-4 border-dashed">
            {prayer.content}
          </p>
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center pt-1">
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <Clock className="w-3.5 h-3.5" />
            <span>{formatDate(prayer.createdAt)}</span>
          </div>
          
          <button 
            onClick={() => onPray(prayer.id)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-green-50 text-green-700 hover:bg-green-100 transition-colors"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span className="text-sm font-semibold">Prayed {prayer.prayedCount}x</span>
          </button>
        </div>
      </div>
    </div>
  );
};
