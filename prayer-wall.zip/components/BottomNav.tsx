import React from 'react';
import { Home, BookOpen, Heart, BarChart2, User } from 'lucide-react';

export const BottomNav: React.FC = () => {
  return (
    <nav className="sticky bottom-0 w-full bg-white/90 backdrop-blur-md border-t border-slate-100 pb-safe pt-2 px-6 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.02)] z-40">
      <ul className="flex justify-between items-center h-16 max-w-md mx-auto">
        <li className="flex flex-col items-center gap-1 cursor-pointer group">
          <Home className="w-6 h-6 text-slate-400 group-hover:text-emerald-500 transition-colors" />
          <span className="text-[10px] font-medium text-slate-400 group-hover:text-emerald-500">Home</span>
        </li>
        <li className="flex flex-col items-center gap-1 cursor-pointer group">
          <BookOpen className="w-6 h-6 text-slate-400 group-hover:text-emerald-500 transition-colors" />
          <span className="text-[10px] font-medium text-slate-400 group-hover:text-emerald-500">Read</span>
        </li>
        <li className="flex flex-col items-center gap-1 cursor-pointer">
          <Heart className="w-6 h-6 text-emerald-500 fill-emerald-500 drop-shadow-sm" />
          <span className="text-[10px] font-bold text-emerald-600">Prayers</span>
        </li>
        <li className="flex flex-col items-center gap-1 cursor-pointer group">
          <BarChart2 className="w-6 h-6 text-slate-400 group-hover:text-emerald-500 transition-colors" />
          <span className="text-[10px] font-medium text-slate-400 group-hover:text-emerald-500">Progress</span>
        </li>
        <li className="flex flex-col items-center gap-1 cursor-pointer group">
          <User className="w-6 h-6 text-slate-400 group-hover:text-emerald-500 transition-colors" />
          <span className="text-[10px] font-medium text-slate-400 group-hover:text-emerald-500">Profile</span>
        </li>
      </ul>
    </nav>
  );
};
