import { CategoryType, Prayer, PrayerStatus } from './types';

export const MOCK_PRAYERS: Prayer[] = [
  {
    id: '1',
    title: "Healing for Grandma's Surgery",
    content: "Please pray for a successful operation and quick recovery. Let her feel your comforting presence.",
    category: CategoryType.FAMILY,
    status: PrayerStatus.ONGOING,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    prayedCount: 24,
  },
  {
    id: '2',
    title: "Wisdom for New Job",
    content: "Asking for clarity and a smooth path ahead as I start this new chapter in my career.",
    category: CategoryType.GUIDANCE,
    status: PrayerStatus.ONGOING,
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    prayedCount: 12,
  },
  {
    id: '3',
    title: "Peace in difficult times",
    content: "Lord, grant me peace that surpasses all understanding during this stressful month.",
    category: CategoryType.HEALTH,
    status: PrayerStatus.ANSWERED,
    createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
    prayedCount: 45,
  }
];

export const DAILY_VERSE = "Do not be anxious about anything, but in every situation, by prayer and petition, present your requests to God.";
