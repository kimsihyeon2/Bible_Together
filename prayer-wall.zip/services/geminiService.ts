import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generatePrayerSuggestion = async (topic: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Write a short, compassionate, and comforting prayer (max 40 words) about the following topic: "${topic}". The tone should be gentle and hopeful. Do not include a title, just the prayer text.`,
    });
    return response.text?.trim() || "Lord, hear our prayer.";
  } catch (error) {
    console.error("Error generating prayer:", error);
    return "Lord, please guide us and give us strength.";
  }
};
