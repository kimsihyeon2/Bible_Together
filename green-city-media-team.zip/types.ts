import { LucideIcon } from 'lucide-react';

export interface Member {
  id: string;
  name: string;
  role: string;
  icon: LucideIcon;
  color: string;
  description: string;
  email: string;
  tags?: string[];
  stats?: {
    projects: number;
    impact: string;
  };
}

export interface TeamData {
  leader: Member;
  members: Member[];
}