import React from 'react';
import OrgChart from './components/OrgChart';

const App: React.FC = () => {
  return (
    <div className="w-full min-h-screen">
      <OrgChart />
    </div>
  );
};

export default App;